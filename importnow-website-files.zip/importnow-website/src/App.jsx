import { useState } from 'react'

const services = [
  { number: '01', title: 'Product sourcing', text: 'Find reliable manufacturers and the right products for your market.' },
  { number: '02', title: 'Import assistance', text: 'Get guidance with documentation, customs and the import process.' },
  { number: '03', title: 'Shipping & logistics', text: 'Coordinate shipments and keep your supply chain moving.' },
]

const steps = [
  ['Tell us what you need', 'Share the product, quantity and destination.'],
  ['Get a sourcing plan', 'We help you understand the next steps and options.'],
  ['Move your shipment', 'Coordinate the process through delivery.'],
]

function App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [form, setForm] = useState({ name: '', phone: '', product: '', message: '' })

  const update = (event) => setForm({ ...form, [event.target.name]: event.target.value })

  const submitQuote = (event) => {
    event.preventDefault()
    const message = `Hello ImportNow! I would like a quote.%0AName: ${encodeURIComponent(form.name)}%0APhone: ${encodeURIComponent(form.phone)}%0AProduct: ${encodeURIComponent(form.product)}%0ADetails: ${encodeURIComponent(form.message)}`
    // Replace this number with your business WhatsApp number, including country code.
    window.open(`https://wa.me/910000000000?text=${message}`, '_blank', 'noopener,noreferrer')
  }

  return (
    <>
      <header className="site-header">
        <a className="brand" href="#home" aria-label="ImportNow home">
          <span className="brand-mark">IN</span><span>Import<span className="brand-accent">Now</span></span>
        </a>
        <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation">☰</button>
        <nav className={menuOpen ? 'nav nav-open' : 'nav'}>
          <a href="#services" onClick={() => setMenuOpen(false)}>Services</a>
          <a href="#process" onClick={() => setMenuOpen(false)}>How it works</a>
          <a href="#about" onClick={() => setMenuOpen(false)}>About</a>
          <a className="nav-cta" href="#quote" onClick={() => setMenuOpen(false)}>Get a quote <span>↗</span></a>
        </nav>
      </header>

      <main>
        <section className="hero" id="home">
          <div className="hero-copy">
            <p className="eyebrow"><span className="eyebrow-dot" /> YOUR GLOBAL TRADE PARTNER</p>
            <h1>Make global sourcing <em>simple.</em></h1>
            <p className="hero-lead">From finding the right products to moving them across borders, ImportNow helps make your import journey clearer and easier.</p>
            <div className="hero-actions">
              <a className="button button-primary" href="#quote">Request a quote <span>↗</span></a>
              <a className="text-link" href="#services">Explore services <span>→</span></a>
            </div>
            <div className="hero-note"><span className="note-icon">✓</span> Practical support for every step of your import journey</div>
          </div>
          <div className="hero-visual">
            <div className="visual-glow" />
            <div className="visual-card card-top"><span className="mini-icon">↗</span><div><strong>Global reach</strong><small>Connecting markets</small></div></div>
            <div className="globe-art" aria-label="Abstract global trade illustration">
              <div className="globe-lines" /><div className="globe-core">IN</div>
              <span className="orbit orbit-one" /><span className="orbit orbit-two" />
              <span className="pin pin-one">✦</span><span className="pin pin-two">•</span>
            </div>
            <div className="visual-card card-bottom"><span className="mini-icon">✓</span><div><strong>Trade made clearer</strong><small>One step at a time</small></div></div>
            <div className="visual-caption">SOURCE <b>·</b> SHIP <b>·</b> SUCCEED</div>
          </div>
        </section>

        <section className="trust-strip" aria-label="Our approach">
          <span>BUILT AROUND YOUR BUSINESS</span><b>Clear communication</b><i /> <b>Practical guidance</b><i /> <b>End-to-end thinking</b>
        </section>

        <section className="section services-section" id="services">
          <div className="section-heading">
            <p className="eyebrow">WHAT WE DO</p>
            <h2>Import with more <em>confidence.</em></h2>
            <p>Support that helps turn your product idea into a clear, actionable import plan.</p>
          </div>
          <div className="service-grid">
            {services.map((service) => <article className="service-card" key={service.number}>
              <span className="service-number">{service.number}</span>
              <div className="service-icon">{service.number === '01' ? '⌕' : service.number === '02' ? '⇄' : '⌁'}</div>
              <h3>{service.title}</h3><p>{service.text}</p><a href="#quote" aria-label={`Ask about ${service.title}`}>Learn more <span>↗</span></a>
            </article>)}
          </div>
        </section>

        <section className="process-section" id="process">
          <div className="process-intro">
            <p className="eyebrow">A SIMPLE PROCESS</p>
            <h2>From idea to <em>arrival.</em></h2>
            <p>Every import starts with a question. We help you take the next step with a straightforward process.</p>
            <a className="button button-light" href="#quote">Start a conversation <span>↗</span></a>
          </div>
          <div className="steps">
            {steps.map((step, index) => <div className="step" key={step[0]}>
              <span className="step-number">0{index + 1}</span><div><h3>{step[0]}</h3><p>{step[1]}</p></div>
            </div>)}
          </div>
        </section>

        <section className="about-section section" id="about">
          <div className="about-symbol"><span>IN</span><div className="symbol-ring" /></div>
          <div className="about-copy"><p className="eyebrow">ABOUT IMPORTNOW</p><h2>Good trade starts with a <em>good partner.</em></h2><p>We believe importing should feel understandable, not overwhelming. ImportNow is focused on helping businesses navigate sourcing and logistics with clear communication and dependable support.</p><a className="text-link" href="#quote">Let's talk about your needs <span>→</span></a></div>
        </section>

        <section className="quote-section" id="quote">
          <div className="quote-copy"><p className="eyebrow">LET'S GET STARTED</p><h2>What are you looking to <em>import?</em></h2><p>Tell us a little about your requirement. Submit the form to open WhatsApp with your details ready to send.</p>
            <div className="contact-note"><span>✉</span><div><strong>Have a question?</strong><small>Share your requirement and start a conversation.</small></div></div>
          </div>
          <form className="quote-form" onSubmit={submitQuote}>
            <label>Your name<input name="name" value={form.name} onChange={update} placeholder="Enter your name" required /></label>
            <label>Phone number<input name="phone" value={form.phone} onChange={update} placeholder="Enter your phone number" required /></label>
            <label>Product you want to import<input name="product" value={form.product} onChange={update} placeholder="e.g. Electronics, textiles..." required /></label>
            <label>More details<textarea name="message" value={form.message} onChange={update} placeholder="Quantity, destination or any questions..." rows="3" /></label>
            <button className="button button-primary submit-button" type="submit">Continue on WhatsApp <span>↗</span></button>
            <small className="form-footnote">Please replace the sample WhatsApp number in src/App.jsx with your business number before publishing.</small>
          </form>
        </section>
      </main>

      <footer className="footer"><a className="brand footer-brand" href="#home"><span className="brand-mark">IN</span><span>Import<span className="brand-accent">Now</span></span></a><span>Global sourcing made simple.</span><a href="#home">Back to top ↑</a><small>© {new Date().getFullYear()} ImportNow. All rights reserved.</small></footer>
    </>
  )
}

export default App
